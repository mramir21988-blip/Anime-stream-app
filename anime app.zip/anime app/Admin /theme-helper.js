// ===== THEME PERSISTENCE HELPER =====
(function() {
  const THEME_CONFIG = {
    naruto:   { color: '#FF6B00', glow: 'rgba(255,107,0,0.5)' },
    tanjiro:  { color: '#2E8B57', glow: 'rgba(46,139,87,0.5)' },
    gojo:     { color: '#00D4FF', glow: 'rgba(0,212,255,0.5)' },
    luffy:    { color: '#DC143C', glow: 'rgba(220,20,60,0.5)' },
    lelouch:  { color: '#8A2BE2', glow: 'rgba(138,43,226,0.5)' },
    saitama:  { color: '#FFD700', glow: 'rgba(255,215,0,0.5)' },
    anya:     { color: '#FF69B4', glow: 'rgba(255,105,180,0.5)' },
    vegeta:   { color: '#1E90FF', glow: 'rgba(30,144,255,0.5)' }
  };

  function applySavedTheme() {
    const savedTheme = localStorage.getItem('anime-character-theme') || localStorage.getItem('thrilling_theme');
    const savedColor = localStorage.getItem('thrilling_theme_color');
    const savedGlow = localStorage.getItem('thrilling_theme_glow');

    if (savedTheme && THEME_CONFIG[savedTheme]) {
      const config = THEME_CONFIG[savedTheme];
      document.documentElement.style.setProperty('--accent', config.color);
      document.documentElement.style.setProperty('--accent-glow', config.glow);
      document.documentElement.style.setProperty('--accent-secondary', config.color);
      document.documentElement.style.setProperty('--player-accent', config.color);
      document.documentElement.style.setProperty('--player-accent-light', config.color);
      document.body.classList.add('theme-' + savedTheme);
    } else if (savedColor) {
      document.documentElement.style.setProperty('--accent', savedColor);
      document.documentElement.style.setProperty('--accent-glow', savedGlow || savedColor + '80');
      document.documentElement.style.setProperty('--player-accent', savedColor);
      document.documentElement.style.setProperty('--player-accent-light', savedColor);
    }
  }

  applySavedTheme();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applySavedTheme);
  }
})();
